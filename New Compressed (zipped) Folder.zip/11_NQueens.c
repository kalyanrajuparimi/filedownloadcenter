#include <stdio.h>
#include <stdlib.h>
int N;
int safe(int board[], int row, int col){
    for(int i=0;i<row;i++){
        if(board[i]==col || abs(board[i]-col)==abs(i-row)) return 0;
    }
    return 1;
}
void printSolution(int board[]){
    for(int i=0;i<N;i++){
        for(int j=0;j<N;j++) printf(board[i]==j? "Q ":". ");
        printf("\n");
    }
    printf("\n");
}
void solve(int board[], int row){
    if(row==N){ printSolution(board); return; }
    for(int col=0; col<N; col++){
        if(safe(board,row,col)){
            board[row]=col; solve(board, row+1);
        }
    }
}
int main(){ if(scanf("%d", &N)!=1) return 0; int *board = malloc(sizeof(int)*N); solve(board,0); free(board); return 0; }