#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
int n; int best = INT_MAX; int path_best[20];
void tspRec(int graph[][20], int curr, int visited[], int count, int cost, int path[]){
    if(cost >= best) return;
    if(count==n && graph[curr][0]){
        int total = cost + graph[curr][0];
        if(total < best){ best=total; for(int i=0;i<n;i++) path_best[i]=path[i]; }
        return;
    }
    for(int i=0;i<n;i++){
        if(!visited[i] && graph[curr][i]){
            visited[i]=1; path[count]=i;
            tspRec(graph, i, visited, count+1, cost+graph[curr][i], path);
            visited[i]=0;
        }
    }
}
int main(){
    if(scanf("%d", &n)!=1) return 0;
    int graph[20][20];
    for(int i=0;i<n;i++) for(int j=0;j<n;j++) if(scanf("%d", &graph[i][j])!=1) return 0;
    int visited[20]={0}; int path[20]; visited[0]=1; path[0]=0;
    tspRec(graph, 0, visited, 1, 0, path);
    if(best==INT_MAX) printf("No Hamiltonian cycle found.\n"); else { printf("%d\n0 ", best); for(int i=1;i<n;i++) printf("%d ", path_best[i]); printf("0\n"); }
    return 0;
}