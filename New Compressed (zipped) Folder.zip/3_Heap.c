#include <stdio.h>
#include <stdlib.h>
void swap(int *a,int *b){int t=*a;*a=*b;*b=t;}
void maxHeapify(int arr[], int n, int i){
    int largest = i; int l = 2*i+1; int r = 2*i+2;
    if(l<n && arr[l]>arr[largest]) largest=l;
    if(r<n && arr[r]>arr[largest]) largest=r;
    if(largest!=i){ swap(&arr[i], &arr[largest]); maxHeapify(arr,n,largest);} }
void minHeapify(int arr[], int n, int i){
    int smallest=i; int l=2*i+1; int r=2*i+2;
    if(l<n && arr[l]<arr[smallest]) smallest=l;
    if(r<n && arr[r]<arr[smallest]) smallest=r;
    if(smallest!=i){ swap(&arr[i], &arr[smallest]); minHeapify(arr,n,smallest);} }
void buildMaxHeap(int arr[], int n){ for(int i=n/2-1;i>=0;i--) maxHeapify(arr,n,i); }
void buildMinHeap(int arr[], int n){ for(int i=n/2-1;i>=0;i--) minHeapify(arr,n,i); }
int main(){
    int n; if(scanf("%d", &n)!=1) return 0;
    int *arr = (int*)malloc(sizeof(int)*n);
    for(int i=0;i<n;i++) if(scanf("%d", &arr[i])!=1) return 0;
    int choice; if(scanf("%d", &choice)!=1) return 0;
    if(choice==1){ buildMaxHeap(arr,n); for(int i=0;i<n;i++) printf("%d ", arr[i]); }
    else { buildMinHeap(arr,n); for(int i=0;i<n;i++) printf("%d ", arr[i]); }
    printf("\n"); free(arr); return 0;
}