#include <stdio.h>
#include <stdlib.h>
typedef struct Node{ int v; struct Node* next;} Node;
Node* newNode(int v){ Node* node = malloc(sizeof(Node)); node->v=v; node->next=NULL; return node; }
void addEdgeList(Node* adj[], int u, int v){ Node* node = newNode(v); node->next = adj[u]; adj[u] = node; }
void bfs_matrix(int n, int adj[n][n], int src){
    int *visited = calloc(n, sizeof(int)); int *queue = malloc(sizeof(int)*n); int front=0, rear=0;
    visited[src]=1; queue[rear++]=src;
    while(front<rear){ int u=queue[front++]; printf("%d ", u);
        for(int v=0;v<n;v++) if(adj[u][v] && !visited[v]){ visited[v]=1; queue[rear++]=v; }
    }
    free(visited); free(queue);
}
void dfs_matrix_util(int n, int adj[n][n], int u, int visited[]){ visited[u]=1; printf("%d ", u);
    for(int v=0;v<n;v++) if(adj[u][v] && !visited[v]) dfs_matrix_util(n, adj, v, visited);
}
void dfs_matrix(int n, int adj[n][n], int src){ int *visited = calloc(n,sizeof(int)); dfs_matrix_util(n,adj,src,visited); free(visited); }
void bfs_list(Node* adj[], int n, int src){ int *visited = calloc(n,sizeof(int)); int *q = malloc(sizeof(int)*n); int front=0, rear=0; visited[src]=1; q[rear++]=src;
    while(front<rear){ int u=q[front++]; printf("%d ", u); for(Node* p=adj[u]; p; p=p->next) if(!visited[p->v]){ visited[p->v]=1; q[rear++]=p->v; } }
    free(visited); free(q);
}
void dfs_list_util(Node* adj[], int u, int visited[]){ visited[u]=1; printf("%d ", u); for(Node* p=adj[u]; p; p=p->next) if(!visited[p->v]) dfs_list_util(adj, p->v, visited); }
void dfs_list(Node* adj[], int n, int src){ int *visited = calloc(n,sizeof(int)); dfs_list_util(adj, src, visited); free(visited); }
int main(){
    int n; if(scanf("%d", &n)!=1) return 0;
    int adj[n][n]; for(int i=0;i<n;i++) for(int j=0;j<n;j++) adj[i][j]=0;
    int m,u,v; if(scanf("%d", &m)!=1) return 0;
    for(int i=0;i<m;i++){ if(scanf("%d %d", &u, &v)!=1) return 0; adj[u][v]=1; adj[v][u]=1; }
    int src; if(scanf("%d", &src)!=1) return 0;
    bfs_matrix(n, adj, src); printf("\n"); dfs_matrix(n, adj, src); printf("\n");
    Node** adjList = malloc(sizeof(Node*)*n); for(int i=0;i<n;i++) adjList[i]=NULL;
    for(int i=0;i<n;i++) for(int j=0;j<n;j++) if(adj[i][j]) addEdgeList(adjList, i, j);
    bfs_list(adjList, n, src); printf("\n"); dfs_list(adjList, n, src); printf("\n");
    return 0;
}