#include <stdio.h>
#include <stdlib.h>
void minMax(int arr[], int l, int r, int *min, int *max){
    if(l==r){ *min = *max = arr[l]; return; }
    if(r==l+1){ if(arr[l]<arr[r]){ *min=arr[l]; *max=arr[r]; } else { *min=arr[r]; *max=arr[l]; } return; }
    int mid = (l+r)/2; int min1, max1, min2, max2;
    minMax(arr, l, mid, &min1, &max1);
    minMax(arr, mid+1, r, &min2, &max2);
    *min = (min1<min2)?min1:min2; *max = (max1>max2)?max1:max2;
}
int main(){ int n; if(scanf("%d", &n)!=1) return 0; int arr[n]; for(int i=0;i<n;i++) if(scanf("%d", &arr[i])!=1) return 0;
    int mn,mx; minMax(arr,0,n-1,&mn,&mx); printf("%d %d\n", mn, mx); return 0;
}