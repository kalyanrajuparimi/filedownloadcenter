#include <stdio.h>
#include <limits.h>
#define INF INT_MAX
int minDistance(int dist[], int sptSet[], int n){ int min=INF, min_index=-1; for(int v=0;v<n;v++) if(!sptSet[v] && dist[v]<=min){ min=dist[v]; min_index=v;} return min_index; }
void dijkstra(int graph[][100], int src, int n){ int dist[n]; int sptSet[n]; for(int i=0;i<n;i++){ dist[i]=INF; sptSet[i]=0; }
    dist[src]=0;
    for(int count=0; count<n-1; count++){
        int u = minDistance(dist, sptSet, n); if(u==-1) break; sptSet[u]=1;
        for(int v=0; v<n; v++) if(!sptSet[v] && graph[u][v] && dist[u]!=INF && dist[u]+graph[u][v] < dist[v]) dist[v] = dist[u]+graph[u][v];
    }
    for(int i=0;i<n;i++) printf("%d\n", dist[i]==INF? -1 : dist[i]);
}
int main(){ int n,m,u,v,w; if(scanf("%d %d", &n, &m)!=2) return 0; int graph[100][100]; for(int i=0;i<n;i++) for(int j=0;j<n;j++) graph[i][j]=0;
    for(int i=0;i<m;i++){ if(scanf("%d %d %d", &u, &v, &w)!=3) return 0; graph[u][v]=w; graph[v][u]=w; }
    int src; if(scanf("%d", &src)!=1) return 0; dijkstra(graph, src, n); return 0;
}