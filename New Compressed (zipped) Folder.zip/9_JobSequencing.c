#include <stdio.h>
#include <stdlib.h>
typedef struct Job{ int id; int deadline; int profit; } Job;
int cmp(const void *a, const void *b){ return ((Job*)b)->profit - ((Job*)a)->profit; }
void jobSequencing(Job jobs[], int n){
    qsort(jobs, n, sizeof(Job), cmp);
    int maxd=0; for(int i=0;i<n;i++) if(jobs[i].deadline>maxd) maxd=jobs[i].deadline;
    int *slot = malloc(sizeof(int)*(maxd+1)); for(int i=0;i<=maxd;i++) slot[i]=-1;
    int totalProfit=0;
    for(int i=0;i<n;i++){
        for(int j=jobs[i].deadline;j>0;j--){ if(slot[j]==-1){ slot[j]=i; totalProfit+=jobs[i].profit; break; } }
    }
    for(int i=1;i<=maxd;i++) if(slot[i]!=-1) printf("%d ", jobs[slot[i]].id);
    printf("\n%d\n", totalProfit);
    free(slot);
}
int main(){ int n; if(scanf("%d", &n)!=1) return 0; Job *jobs = malloc(sizeof(Job)*n);
    for(int i=0;i<n;i++) if(scanf("%d %d %d", &jobs[i].id, &jobs[i].deadline, &jobs[i].profit)!=3) return 0;
    jobSequencing(jobs, n); free(jobs); return 0;
}